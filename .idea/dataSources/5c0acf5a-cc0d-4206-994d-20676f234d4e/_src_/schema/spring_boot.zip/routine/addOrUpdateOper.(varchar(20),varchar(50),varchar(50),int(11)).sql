CREATE PROCEDURE addOrUpdateOper(IN opcode VARCHAR(20), IN ophref VARCHAR(50), IN opname VARCHAR(50), IN opseq INT)
  BEGIN
	declare opid int default 0;
	select op.opid intoopid from auth_operation AS op where op.opcode = opcode and op.ophref = ophref;
	if opid > 0 then
		update auth_operation set opname = opname, opseq = opseq 
		where opcode = opcode and ophref = ophref;
		delete from auth_operation where opid = opid;
	else
		insert into auth_operation(opcode, opname, ophref, opseq) 
		values(opcode, opname, ophref, opseq);
	end if;
END;
