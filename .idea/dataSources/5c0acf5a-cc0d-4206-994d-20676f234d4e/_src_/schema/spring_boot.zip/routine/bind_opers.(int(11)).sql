CREATE PROCEDURE bind_opers(IN roleid INT)
  BEGIN
	/*用于判断是否结束循环*/
	declare done int default 0;
	declare opid int;
	declare count int default 0;
	/*定义游标*/
	declare c_opid cursor for select op.opid from auth_operation op;
	/*定义 设置循环结束标识done值怎么改变 的逻辑*/
	declare continue handler for not FOUND set done = 1;
	/*打开游标*/
	open c_opid;
		repeat
			fetch c_opid into opid;
			if not done then 
				select count(op.opid) into count from auth_role_operation op where op.roleid = roleid and op.opid = opid;
				if count <= 0 then
					insert into auth_role_operation(roleid, opid) values(roleid, opid);
				end if;
			end if;
		until done end repeat;
	close c_opid;  /*关闭游标*/
END;
